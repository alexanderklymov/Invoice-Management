﻿using InvoiceSystem.Domain;

namespace InvoiceSystem.Infrastructure.Repositories.Interfaces
{
    public interface IContractRepository
    {
        Task<Contract?> GetValidContractAsync(int employeeId, DateTime invoiceStart, DateTime invoiceEnd);
    }
}
