﻿using InvoiceSystem.Infrastructure.Context;
using InvoiceSystem.Infrastructure.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace InvoiceSystem.Infrastructure.Repositories.Classes
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly IInvoiceManagementDbContext _context;

        public EmployeeRepository(IInvoiceManagementDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Employee>> GetAllEmployeesAsync()
        {
            return await _context.Employees.ToListAsync();
        }

        public async Task<Employee?> GetEmployeeByIdAsync(int employeeId)
        {
            return await _context.Employees.FindAsync(employeeId);
        }

        public async Task<Employee?> GetEmployeeByNameAsync(string employeeName)
        {
            if (string.IsNullOrWhiteSpace(employeeName))
                return null;

            var loweredName = employeeName.ToLower();

            return await _context.Employees
                .FirstOrDefaultAsync(e => e.FirstName.ToLower() == loweredName);
        }
    }
}
