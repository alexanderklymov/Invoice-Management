﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace InvoiceSystem.Domain
{
    public class Invoice
    {
        [Required]
        public int Id { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int DaysWorked { get; set; }
        public decimal TotalAmount { get; set; }
        public Employee Employee { get; set; } = null!;

        [ForeignKey(nameof(Employee))]
        public int EmployeeId { get; set; }

    }
}
