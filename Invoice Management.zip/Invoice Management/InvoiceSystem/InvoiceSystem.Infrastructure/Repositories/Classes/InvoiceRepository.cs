﻿using InvoiceSystem.Domain;
using InvoiceSystem.Infrastructure.Context;
using InvoiceSystem.Infrastructure.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace InvoiceSystem.Infrastructure.Repositories.Classes
{
    public class InvoiceRepository : IInvoiceRepository
    {
        private readonly IInvoiceManagementDbContext _context;

        public InvoiceRepository(IInvoiceManagementDbContext context)
        {
           _context = context;
        }

        public async Task AddInvoiceAsync(Invoice invoice)
        {
            await _context.Invoices.AddAsync(invoice);
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Invoice>> GetAllInvoicesAsync()
        {
            return await _context.Invoices.Include(i => i.Employee).ToListAsync();
        }

        public async Task<Invoice?> GetInvoiceByIdAsync(int invoiceId)
        {
            return await _context.Invoices
           .Include(i => i.Employee)
           .FirstOrDefaultAsync(i => i.Id == invoiceId);
        }

        public async Task<IEnumerable<Invoice>> GetInvoicesByEmployeeIdAsync(int employeeId)
        {
            return await _context.Invoices
                .Include(i => i.Employee)
                .Where(i => i.EmployeeId == employeeId)
                .ToListAsync();
        }

        public async Task<bool> InvoiceExistsForPeriodAsync(int employeeId, DateTime startDate, DateTime endDate)
        {
            return await _context.Invoices.AnyAsync(i =>
                 i.EmployeeId == employeeId &&
                 i.StartDate <= endDate &&
                 i.EndDate >= startDate);
        }
    }
}
