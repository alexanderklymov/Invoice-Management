﻿using AutoMapper;
using InvoiceSystem.Application.DTOs;
using InvoiceSystem.Domain;

namespace InvoiceSystem.Application.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Employee, EmployeeDto>()
                .ForMember(dest => dest.FullName, opt => opt.MapFrom(src => src.FirstName + " " + src.LastName));

            CreateMap<Invoice, InvoiceDto>()
                .ForMember(dest => dest.FullName,
               opt => opt.MapFrom(src => src.Employee.FirstName + " " + src.Employee.LastName));
            CreateMap<CreateInvoiceDto, Invoice>();
        }
    }
}

