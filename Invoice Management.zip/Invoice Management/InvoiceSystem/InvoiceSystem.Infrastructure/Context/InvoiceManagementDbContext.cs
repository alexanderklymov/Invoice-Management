﻿using InvoiceSystem.Domain;
using Microsoft.EntityFrameworkCore;

namespace InvoiceSystem.Infrastructure.Context
{
    public class InvoiceManagementDbContext : DbContext, IInvoiceManagementDbContext
    {
        public InvoiceManagementDbContext(DbContextOptions<InvoiceManagementDbContext> options) :
            base(options) { }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Invoice> Invoices { get; set; }
        public DbSet<Contract> Contracts { get; set; } 

        public async Task<int> SaveChangesAsync()
        {
            return await base.SaveChangesAsync();
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Seeding Employees
            modelBuilder.Entity<Employee>().HasData(
                new Employee { Id = 1, FirstName = "Frank", LastName = "Lampard", Role = "InvoiceManager" },
                new Employee { Id = 2, FirstName = "Steven", LastName = "Gerrard", Role = "Employee" },
                new Employee { Id = 3, FirstName = "Alisha", LastName = "Lehmann", Role = "Employee" },
                new Employee { Id = 4, FirstName = "Stan", LastName = "Wawrinka", Role = "Employee" }
            );

            // Seeding Invoices
            modelBuilder.Entity<Invoice>().HasData(
                new Invoice
                {
                    Id = 1,
                    EmployeeId = 2,
                    StartDate = new DateTime(2025, 1, 1),
                    EndDate = new DateTime(2025, 1, 11),
                    DaysWorked = 11,
                    TotalAmount = 1000
                },
                new Invoice
                 {
                     Id = 2,
                     EmployeeId = 3,
                     StartDate = new DateTime(2024, 6, 5),
                     EndDate = new DateTime(2024, 6, 10),
                     DaysWorked = 6,
                     TotalAmount = 1080
                }
            );

            modelBuilder.Entity<Contract>().HasData(
                 new Contract { Id = 1, EmployeeId = 1, StartDate = new DateTime(2024, 1, 1), EndDate = new DateTime(2025, 12, 31), DailyRate = 200 },
                 new Contract { Id = 2, EmployeeId = 2, StartDate = new DateTime(2024, 5, 1), EndDate = new DateTime(2024, 11, 30), DailyRate = 150 },
                 new Contract { Id = 3, EmployeeId = 2, StartDate = new DateTime(2024, 12, 1), EndDate = new DateTime(2025, 12, 31), DailyRate = 100 },
                 new Contract { Id = 4, EmployeeId = 3, StartDate = new DateTime(2024, 6, 1), EndDate = new DateTime(2024, 11, 30), DailyRate = 180 }
            );

            // Unique index: Prevent duplicate contracts
            modelBuilder.Entity<Contract>()
                .HasIndex(c => new { c.EmployeeId, c.StartDate, c.EndDate })
                .IsUnique();

            // Unique index: Prevent duplicate invoices for same period
            modelBuilder.Entity<Invoice>()
                .HasIndex(i => new { i.EmployeeId, i.StartDate, i.EndDate })
                .IsUnique();
        }
    }
}
