﻿using AutoMapper;
using InvoiceSystem.Application.DTOs;
using InvoiceSystem.Application.Services.Interfaces;
using InvoiceSystem.Infrastructure.Repositories.Interfaces;

namespace InvoiceSystem.Application.Services.Classes
{
    public class LoginService : ILoginService
    {
        private readonly IEmployeeRepository _employeeRepository;
        private readonly IMapper _mapper;

        public LoginService(IEmployeeRepository employeeRepository, IMapper mapper)
        {
            _employeeRepository = employeeRepository;
            _mapper = mapper;
        }

        public async Task<EmployeeDto?> AuthenticateAsync(string username)
        {
            var employee = await _employeeRepository.GetEmployeeByNameAsync(username);
            return employee == null ? null : _mapper.Map<EmployeeDto>(employee);
        }
    }
}
