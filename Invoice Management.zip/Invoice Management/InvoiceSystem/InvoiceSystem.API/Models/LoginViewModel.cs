﻿using System.ComponentModel.DataAnnotations;

namespace InvoiceSystem.API.Models
{
    public class LoginViewModel
    {
        [Required]
        public string Username { get; set; } = string.Empty;
    }
}