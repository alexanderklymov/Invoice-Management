﻿namespace InvoiceSystem.Application.DTOs
{
    public class ValidationResultDto
    {
        public bool Success { get; set; }
        public string? ErrorMessage { get; set; }

        public static ValidationResultDto Fail(string message) =>
            new ValidationResultDto { Success = false, ErrorMessage = message };

        public static ValidationResultDto Ok() =>
            new ValidationResultDto { Success = true };
    }
}
