﻿using InvoiceSystem.Domain;
using System.ComponentModel.DataAnnotations;

public class Employee
{
    [Key]
    public int Id { get; set; }
    [Required]
    public string FirstName { get; set; } = null!;
    [Required]
    public string LastName { get; set; } = null!;
    public string Role { get; set; } = null!;
    public ICollection<Contract> Contracts { get; set; } = null!;
    public ICollection<Invoice> Invoices { get; set; } = null!;


}
