﻿using InvoiceSystem.Application.DTOs;

namespace InvoiceSystem.Application.Services.Interfaces
{
    public interface IInvoiceManagementService
    {
        Task<InvoiceDto?> GetInvoiceByIdAsync(int id);
        Task<IEnumerable<InvoiceDto>> GetInvoicesForUserAsync(int userId, bool isManager);
        Task<ValidationResultDto> ValidateAndCreateInvoiceAsync(CreateInvoiceDto invoice);
        Task<IEnumerable<EmployeeDto>> GetAllEmployeesAsync();
        Task<EmployeeDto> GetEmployeeByIdAsync(int employeeId);
    }
}
