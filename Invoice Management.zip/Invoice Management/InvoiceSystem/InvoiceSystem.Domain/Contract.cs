﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace InvoiceSystem.Domain
{
    public class Contract
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public DateTime StartDate { get; set; }

        [Required]
        public DateTime EndDate { get; set; }

        [Required]
        public decimal DailyRate { get; set; }

        public Employee Employee { get; set; } = null!;

        [ForeignKey(nameof(Employee))]
        public int EmployeeId { get; set; }

        // Ensure that contract is valid
        public bool IsValid(DateTime date)
        {
            return date >= StartDate && date <= EndDate;
        }

        [NotMapped]
        public bool IsActive
        {
            get { return DateTime.UtcNow >= StartDate && DateTime.UtcNow <= EndDate; }
        }
    }

}
