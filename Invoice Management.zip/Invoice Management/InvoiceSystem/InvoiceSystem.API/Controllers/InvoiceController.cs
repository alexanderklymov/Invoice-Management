﻿using InvoiceSystem.API.Models;
using InvoiceSystem.Application.DTOs;
using InvoiceSystem.Application.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace InvoiceSystem.API.Controllers
{
    [Authorize]
    public class InvoiceController : Controller
    {
        private readonly IInvoiceManagementService _invoiceManagementService;

        public InvoiceController(IInvoiceManagementService invoiceManagementService)
        {
            _invoiceManagementService = invoiceManagementService;
        }

        [Authorize]
        public async Task<IActionResult> Index()
        {
            var role = User.FindFirstValue(ClaimTypes.Role);
            var userIdStr = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdStr, out int userId))
            {
                return BadRequest("Invalid user ID");
            }

            var isManager = role == "InvoiceManager";
            var invoices = await _invoiceManagementService.GetInvoicesForUserAsync(userId, isManager);
            return View(invoices);
        }

        [Authorize(Roles = "InvoiceManager")]
        [HttpGet]
        public async Task<IActionResult> Create()
        {
            ViewBag.Employees = await _invoiceManagementService.GetAllEmployeesAsync();
            return View();
        }

        [Authorize(Roles = "InvoiceManager")]
        [HttpPost]
        public async Task<IActionResult> Create(InvoiceViewModel model)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Employees = await _invoiceManagementService.GetAllEmployeesAsync();
                return View(model);
            }

            var dto = new CreateInvoiceDto
            {
                EmployeeId = model.EmployeeId,
                StartDate = model.StartDate,
                EndDate = model.EndDate,
                DaysWorked = model.DaysWorked,
                TotalAmount = model.TotalAmount
            };

            var result = await _invoiceManagementService.ValidateAndCreateInvoiceAsync(dto);
            if (!result.Success)
            {
                ViewData["ErrorMessage"] = result.ErrorMessage;
                ViewBag.Employees = await _invoiceManagementService.GetAllEmployeesAsync();
                return View(model);
            }

            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Details(int id)
        {
            var invoice = await _invoiceManagementService.GetInvoiceByIdAsync(id);
            if (invoice == null)
            {
                return NotFound();
            }

            return View(invoice);
        }
    }
}
