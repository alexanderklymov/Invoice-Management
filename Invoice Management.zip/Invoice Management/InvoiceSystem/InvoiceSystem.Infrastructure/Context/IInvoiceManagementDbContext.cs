﻿using InvoiceSystem.Domain;
using Microsoft.EntityFrameworkCore;

namespace InvoiceSystem.Infrastructure.Context
{
    public interface IInvoiceManagementDbContext
    {
        DbSet<Employee> Employees { get; set; }
        DbSet<Invoice> Invoices { get; set; }
        DbSet<Contract> Contracts { get; set; }
        Task<int> SaveChangesAsync();
    }
}
