﻿namespace InvoiceSystem.Infrastructure.Repositories.Interfaces
{
    public interface IEmployeeRepository
    {
        Task<Employee?> GetEmployeeByIdAsync(int employeeId);
        Task<Employee?> GetEmployeeByNameAsync(string employeeName);
        Task<IEnumerable<Employee>> GetAllEmployeesAsync();
    }
}
