﻿using InvoiceSystem.Application.DTOs;

namespace InvoiceSystem.Application.Services.Interfaces
{
    public interface ILoginService
    {
        Task<EmployeeDto?> AuthenticateAsync(string username);
    }
}
