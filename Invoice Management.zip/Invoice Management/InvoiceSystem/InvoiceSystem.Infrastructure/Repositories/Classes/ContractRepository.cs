﻿using InvoiceSystem.Domain;
using InvoiceSystem.Infrastructure.Context;
using InvoiceSystem.Infrastructure.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace InvoiceSystem.Infrastructure.Repositories.Classes
{
    public class ContractRepository : IContractRepository
    {
        private readonly IInvoiceManagementDbContext _context;

        public ContractRepository(IInvoiceManagementDbContext context)
        {
            _context = context;
        }

        public async Task<Contract?> GetValidContractAsync(int employeeId, DateTime invoiceStart, DateTime invoiceEnd)
        {
            return await _context.Contracts
               .Where(c => c.EmployeeId == employeeId &&
                           c.StartDate <= invoiceStart &&
                           c.EndDate >= invoiceEnd)
               .FirstOrDefaultAsync();
        }
    }
}
