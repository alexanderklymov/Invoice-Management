﻿using InvoiceSystem.Domain;

namespace InvoiceSystem.Infrastructure.Repositories.Interfaces
{
    public interface IInvoiceRepository
    {
        Task<IEnumerable<Invoice>> GetAllInvoicesAsync();
        Task<IEnumerable<Invoice>> GetInvoicesByEmployeeIdAsync(int employeeId);
        Task<Invoice?> GetInvoiceByIdAsync(int invoiceId);
        Task AddInvoiceAsync(Invoice invoice);
        Task<bool> InvoiceExistsForPeriodAsync(int employeeId, DateTime startDate, DateTime endDate);
    }
}
