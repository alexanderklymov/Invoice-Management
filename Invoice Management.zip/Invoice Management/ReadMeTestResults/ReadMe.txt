To run the solution please set InvoiceSystem.API as start-up project

For testing USE CASE 1 please login as Frank.

For testing USE CASE 2 please login as Steven.