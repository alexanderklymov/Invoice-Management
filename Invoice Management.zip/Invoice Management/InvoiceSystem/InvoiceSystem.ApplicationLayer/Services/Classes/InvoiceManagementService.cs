﻿using AutoMapper;
using InvoiceSystem.Application.DTOs;
using InvoiceSystem.Application.Services.Interfaces;
using InvoiceSystem.Domain;
using InvoiceSystem.Infrastructure.Repositories.Interfaces;

namespace InvoiceSystem.Application.Services.Classes
{
    public class InvoiceManagementService : IInvoiceManagementService
    {
        private readonly IInvoiceRepository _invoiceRepository;
        private readonly IContractRepository _contractRepository;
        private readonly IEmployeeRepository _employeeRepository;
        private readonly IMapper _mapper;

        public InvoiceManagementService(IInvoiceRepository invoiceRepository,
            IContractRepository contractRepository,
            IEmployeeRepository employeeRepository,
            IMapper mapper)
        {
           _invoiceRepository = invoiceRepository;
           _contractRepository = contractRepository;
           _employeeRepository = employeeRepository;
           _mapper = mapper;
        }

        public async Task<IEnumerable<EmployeeDto>> GetAllEmployeesAsync()
        {
            var employees = await _employeeRepository.GetAllEmployeesAsync();
            return _mapper.Map<IEnumerable<EmployeeDto>>(employees);
        }

        public async Task<EmployeeDto> GetEmployeeByIdAsync(int employeeId)
        {
            var employee = await _employeeRepository.GetEmployeeByIdAsync(employeeId);

            if (employee == null)
                throw new KeyNotFoundException($"Employee with ID {employeeId} not found.");

            return _mapper.Map<EmployeeDto>(employee);
        }

        public async Task<InvoiceDto?> GetInvoiceByIdAsync(int id)
        {
            var invoice = await _invoiceRepository.GetInvoiceByIdAsync(id);
            if (invoice == null) return null;

            return _mapper.Map<InvoiceDto>(invoice);
        }

        public async Task<IEnumerable<InvoiceDto>> GetInvoicesForUserAsync(int userId, bool isManager)
        {
            var invoices = isManager
                    ? await _invoiceRepository.GetAllInvoicesAsync()
                    : await _invoiceRepository.GetInvoicesByEmployeeIdAsync(userId);

            return _mapper.Map<IEnumerable<InvoiceDto>>(invoices);
        }

        public async Task<ValidationResultDto> ValidateAndCreateInvoiceAsync(CreateInvoiceDto dto)
        {
            var employee = await _employeeRepository.GetEmployeeByIdAsync(dto.EmployeeId);
            if (employee == null)
                return ValidationResultDto.Fail("Employee not found.");

            var contract = await _contractRepository.GetValidContractAsync(dto.EmployeeId, dto.StartDate, dto.EndDate);
            if (contract == null)
                return ValidationResultDto.Fail("No valid contract exists for this invoicing period.");

            var expectedDays = (dto.EndDate - dto.StartDate).Days + 1;
            if (dto.DaysWorked != expectedDays)
                return ValidationResultDto.Fail($"Days worked must match the invoice range: expected {expectedDays}, but got {dto.DaysWorked}.");

            var expectedAmount = expectedDays * contract.DailyRate;
            if (dto.TotalAmount != expectedAmount)
                return ValidationResultDto.Fail($"Total amount is incorrect. Expected {expectedAmount:C} based on {expectedDays} days at {contract.DailyRate:C} per day.");

            bool exists = await _invoiceRepository.InvoiceExistsForPeriodAsync(dto.EmployeeId, dto.StartDate, dto.EndDate);
            if (exists)
                return ValidationResultDto.Fail("An invoice already exists for this period. Please check for overlaps.");

            var invoice = _mapper.Map<Invoice>(dto);
            await _invoiceRepository.AddInvoiceAsync(invoice);
            return ValidationResultDto.Ok();
        }
    }
}
