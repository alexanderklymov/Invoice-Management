﻿namespace InvoiceSystem.Application.DTOs
{
    public class InvoiceDto
    {
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public string FullName { get; set; } = string.Empty;
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int DaysWorked { get; set; }
        public decimal TotalAmount { get; set; }
    }
}
